STATUS_CHOICES =(
    ("0", "Select"),
    ("1", "Active"),
    ("2", "InActive"),

)